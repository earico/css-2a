// Eleazar Rico
// Dr. A
// Feb. 22nd, 2019
// This program displays info on a concert
#include "Concert.h"
using namespace std;

int main(){
    Concert c(30.00, 60.00, "Tennis", "San Francisco's Warfield");

    c.print();

    return 0;
}
